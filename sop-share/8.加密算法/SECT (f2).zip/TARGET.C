/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Copyright (C), Philips Semiconductors PCALH                               */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*                       (C) Philips Electronics N. V. 1995                  */
/* All rights are reserved. Reproduction in whole or in part is prohibited   */
/*             without the written consent of the copyright owner.           */
/*                                                                           */
/*  Philips reserves the right to make changes without notice at any time.   */
/* Philips makes no warranty, expressed, implied or statutory, including but */
/* not limited to any implied warranty of merchantibility or fitness for any */
/*   particular purpose, or that the use will not infringe any third party   */
/* patent,copyright or trademark. Philips must not be liable for any loss or */
/*                       damage arising from its use.                        */
/*---------------------------------------------------------------------------*/
/* Philips GmbH Roehren- und Halbleiterwerke                                 */
/* Product Concept & Application Laboratory Hamburg                          */
/* ACS-ID                                                                    */
/*---------------------------------------------------------------------------*/
/* Name of the Project:                                                      */
/*                                                                           */
/* FILE:    TARGET.C                                                         */
/* Author:  Frank Schl�ter                                                   */
/*---------------------------------------------------------------------------*/
/* References:                                                               */
/*                                                                           */
/* SECT-DESIGN      Design Specification - Security Software for PCF79735    */
/*                  Author: Frank Schl�ter Report: HAC/CC95011               */
/* SECT-ALG         Security Algorithm for PCF79735 report 21.07.95          */
/* SECT-TUT-C       Tutorial Software - C Security algorithm for PCF79735    */
/*                  Security Transponder 07.08.95 Report No.:   HAC/CC95006  */
/* SECT-TUT-ASM     Tutorial Software - Assembler - Algorithm for PCF79735   */
/*                  Security Transponder                                     */
/*---------------------------------------------------------------------------*/
/* Date      |       CHANGES DONE                                  | By      */
/*---------------------------------------------------------------------------*/
/* 24.08.95  | Start                                               | FS      */
/*---------------------------------------------------------------------------*/
/* Description                                                               */

/* Security Algorithm for PCF79735 transponder in C                          */
/* Challenge - Response Protocol Security Transponder                        */
/*---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*/
/* Include files                                                             */
/*---------------------------------------------------------------------------*/
#include "crypto.h"


/*---------------------------------------------------------------------------*/
/* Testpogramm for the 8051 target with fixed authentificator, identificator */
/* and challenge.                                                            */
/*---------------------------------------------------------------------------*/
void main()
{          
    int     Index; /* Index help variable to  initialize the P sequence     */

    /*-----------------------------------------------------------------------*/
    /*  Authenticator:   00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00     */
    /*  Identifier:      00 00 00 00                                         */
    /*  Challenge:       00 00 00 00 00 00                                   */
    /*                                                                       */
    /*  Response:        68 43 F3 61 F9 F0                                   */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0;    /* Initialize A0  */
    A[1]    = 0;    /* Initialize A1  */
    A[2]    = 0;    /* Initialize A2  */
    A[3]    = 0;    /* Initialize A3  */

    P[0]    = 0;    /* Initialize A4  */
    P[1]    = 0;    /* Initialize A5  */
    P[2]    = 0;    /* Initialize A6  */
    P[3]    = 0;    /* Initialize A7  */
    P[4]    = 0;    /* Initialize A8  */
    P[5]    = 0;    /* Initialize A9  */
    P[6]    = 0;    /* Initialize A10 */
    P[7]    = 0;    /* Initialize A11 */
    P[8]    = 0;    /* Initialize A12 */
    P[9]    = 0;    /* Initialize A13 */
    P[10]   = 0;    /* Initialize A14 */
    P[11]   = 0;    /* Initialize A15 */
    P[12]   = 0;    /* Initialize I0  */
    P[13]   = 0;    /* Initialize I1  */
    P[14]   = 0;    /* Initialize I2  */
    P[15]   = 0;    /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0;    /* Initialize H0  */
    H[1]    = 0;    /* Initialize H1  */
    H[2]    = 0;    /* Initialize H2  */
    H[3]    = 0;    /* Initialize H3  */
    H[4]    = 0;    /* Initialize H4  */
    H[5]    = 0;    /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain:  68 43 F3 61 F9 F0                        */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator:  1A 2B 3C 4D 5E 6F E7 D8 C9 BA A9 98 87 76 65 54      */
    /*  Identifier:     FE 00 B4 1A                                          */
    /*  Challenge:      A9 E7 BB 07 4C 33                                    */
    /*                                                                       */
    /*  Response:       34 B7 89 ED 1F 1A                                    */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x1A; /* Initialize A0  */
    A[1]    = 0x2B; /* Initialize A1  */
    A[2]    = 0x3C; /* Initialize A2  */
    A[3]    = 0x4D; /* Initialize A3  */

    P[0]    = 0x5E; /* Initialize A4  */
    P[1]    = 0x6F; /* Initialize A5  */
    P[2]    = 0xE7; /* Initialize A6  */
    P[3]    = 0xD8; /* Initialize A7  */
    P[4]    = 0xC9; /* Initialize A8  */
    P[5]    = 0xBA; /* Initialize A9  */
    P[6]    = 0xA9; /* Initialize A10 */
    P[7]    = 0x98; /* Initialize A11 */
    P[8]    = 0x87; /* Initialize A12 */
    P[9]    = 0x76; /* Initialize A13 */
    P[10]   = 0x65; /* Initialize A14 */
    P[11]   = 0x54; /* Initialize A15 */
    
    P[12]   = 0xFE; /* Initialize I0  */
    P[13]   = 0x00; /* Initialize I1  */
    P[14]   = 0xB4; /* Initialize I2  */
    P[15]   = 0x1A; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0xA9; /* Initialize H0  */
    H[1]    = 0xE7; /* Initialize H1  */
    H[2]    = 0xBB; /* Initialize H2  */
    H[3]    = 0x07; /* Initialize H3  */
    H[4]    = 0x4C; /* Initialize H4  */
    H[5]    = 0x33; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 34 B7 89 ED 1F 1A                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator:  FE DC BA 98 76 54 32 10 12 34 56 78 9A BC DE F0      */
    /*  Identifier:     FE DC BA 98                                          */
    /*  Challenge:      FF FF FF FF FF FF                                    */
    /*                                                                       */
    /*  Response:       18 6E 72 35 19 6E                                    */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0xFE; /* Initialize A0  */
    A[1]    = 0xDC; /* Initialize A1  */
    A[2]    = 0xBA; /* Initialize A2  */
    A[3]    = 0x98; /* Initialize A3  */

    P[0]    = 0x76; /* Initialize A4  */
    P[1]    = 0x54; /* Initialize A5  */
    P[2]    = 0x32; /* Initialize A6  */
    P[3]    = 0x10; /* Initialize A7  */
    P[4]    = 0x12; /* Initialize A8  */
    P[5]    = 0x34; /* Initialize A9  */
    P[6]    = 0x56; /* Initialize A10 */
    P[7]    = 0x78; /* Initialize A11 */
    P[8]    = 0x9A; /* Initialize A12 */
    P[9]    = 0xBC; /* Initialize A13 */
    P[10]   = 0xDE; /* Initialize A14 */
    P[11]   = 0xF0; /* Initialize A15 */
    
    P[12]   = 0xFE; /* Initialize I0  */
    P[13]   = 0xDC; /* Initialize I1  */
    P[14]   = 0xBA; /* Initialize I2  */
    P[15]   = 0x98; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0xFF; /* Initialize H0  */
    H[1]    = 0xFF; /* Initialize H1  */
    H[2]    = 0xFF; /* Initialize H2  */
    H[3]    = 0xFF; /* Initialize H3  */
    H[4]    = 0xFF; /* Initialize H4  */
    H[5]    = 0xFF; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 18 6E 72 35 19 6E                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: A5 0F 3B 44 FF 3E 1A B7 C0 00 11 F3 FF 0A D9 20       */
    /*  Identifier:    04 62 1F FA                                           */
    /*  Challenge:     00 00 00 00 00 00                                     */
    /*                                                                       */
    /*  Response:      86 C0 63 5B 9A D5                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0xA5; /* Initialize A0  */
    A[1]    = 0x0F; /* Initialize A1  */
    A[2]    = 0x3B; /* Initialize A2  */
    A[3]    = 0x44; /* Initialize A3  */

    P[0]    = 0xFF; /* Initialize A4  */
    P[1]    = 0x3E; /* Initialize A5  */
    P[2]    = 0x1A; /* Initialize A6  */
    P[3]    = 0xB7; /* Initialize A7  */
    P[4]    = 0xC0; /* Initialize A8  */
    P[5]    = 0x00; /* Initialize A9  */
    P[6]    = 0x11; /* Initialize A10 */
    P[7]    = 0xF3; /* Initialize A11 */
    P[8]    = 0xFF; /* Initialize A12 */
    P[9]    = 0x0A; /* Initialize A13 */
    P[10]   = 0xD9; /* Initialize A14 */
    P[11]   = 0x20; /* Initialize A15 */
    
    P[12]   = 0x04; /* Initialize I0  */
    P[13]   = 0x62; /* Initialize I1  */
    P[14]   = 0x1F; /* Initialize I2  */
    P[15]   = 0xFA; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x00; /* Initialize H0  */
    H[1]    = 0x00; /* Initialize H1  */
    H[2]    = 0x00; /* Initialize H2  */
    H[3]    = 0x00; /* Initialize H3  */
    H[4]    = 0x00; /* Initialize H4  */
    H[5]    = 0x00; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 86 C0 63 5B 9A D5                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 19 6A 2F AB 32 4D CB AE 5F 99 EE 07 47 AD E0 00       */
    /*  Identifier:    52 13 56 30                                           */
    /*  Challenge:     00 FF 00 FF 00 FF                                     */
    /*                                                                        */
    /*  Response:      75 A6 BE EA 70 19                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x19; /* Initialize A0  */
    A[1]    = 0x6A; /* Initialize A1  */
    A[2]    = 0x2F; /* Initialize A2  */
    A[3]    = 0xAB; /* Initialize A3  */

    P[0]    = 0x32; /* Initialize A4  */
    P[1]    = 0x4D; /* Initialize A5  */
    P[2]    = 0xCB; /* Initialize A6  */
    P[3]    = 0xAE; /* Initialize A7  */
    P[4]    = 0x5F; /* Initialize A8  */
    P[5]    = 0x99; /* Initialize A9  */
    P[6]    = 0xEE; /* Initialize A10 */
    P[7]    = 0x07; /* Initialize A11 */
    P[8]    = 0x47; /* Initialize A12 */
    P[9]    = 0xAD; /* Initialize A13 */
    P[10]   = 0xE0; /* Initialize A14 */
    P[11]   = 0x00; /* Initialize A15 */
    
    P[12]   = 0x52; /* Initialize I0  */
    P[13]   = 0x13; /* Initialize I1  */
    P[14]   = 0x56; /* Initialize I2  */
    P[15]   = 0x30; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x00; /* Initialize H0  */
    H[1]    = 0xFF; /* Initialize H1  */
    H[2]    = 0x00; /* Initialize H2  */
    H[3]    = 0xFF; /* Initialize H3  */
    H[4]    = 0x00; /* Initialize H4  */
    H[5]    = 0xFF; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 75 A6 BE EA 70 19                         */
    /*-----------------------------------------------------------------------*/
/* ab hier */
    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 00 11 22 33 44 55 66 77 88 99 AA BB CC DD EE FF       */
    /*  Identifier:    01 23 45 67                                           */
    /*  Challenge:     FE DC BA 98 76 54                                     */
    /*                                                                       */
    /*  Response:      7E  59 F2 99 53 FF                                    */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x00; /* Initialize A0  */
    A[1]    = 0x11; /* Initialize A1  */
    A[2]    = 0x22; /* Initialize A2  */
    A[3]    = 0x33; /* Initialize A3  */

    P[0]    = 0x44; /* Initialize A4  */
    P[1]    = 0x55; /* Initialize A5  */
    P[2]    = 0x66; /* Initialize A6  */
    P[3]    = 0x77; /* Initialize A7  */
    P[4]    = 0x88; /* Initialize A8  */
    P[5]    = 0x99; /* Initialize A9  */
    P[6]    = 0xAA; /* Initialize A10 */
    P[7]    = 0xBB; /* Initialize A11 */
    P[8]    = 0xCC; /* Initialize A12 */
    P[9]    = 0xDD; /* Initialize A13 */
    P[10]   = 0xEE; /* Initialize A14 */
    P[11]   = 0xFF; /* Initialize A15 */
    
    P[12]   = 0x01; /* Initialize I0  */
    P[13]   = 0x23; /* Initialize I1  */
    P[14]   = 0x45; /* Initialize I2  */
    P[15]   = 0x67; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0xFE; /* Initialize H0  */
    H[1]    = 0xDC; /* Initialize H1  */
    H[2]    = 0xBA; /* Initialize H2  */
    H[3]    = 0x98; /* Initialize H3  */
    H[4]    = 0x76; /* Initialize H4  */
    H[5]    = 0x54; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 7E 59 F2 99 53 FF                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 6D FA 2C 7A 66 F2 B0 7D 9C BB 5E CA E1 96 B3 E3       */
    /*  Identifier:    1B CF 0B C9                                           */
    /*  Challenge:     35 7E 69 1A FC 34                                     */
    /*                                                                        */
    /*  Response:      52 D3 30 5D 3B 15                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x6D; /* Initialize A0  */
    A[1]    = 0xFA; /* Initialize A1  */
    A[2]    = 0x2C; /* Initialize A2  */
    A[3]    = 0x7A; /* Initialize A3  */

    P[0]    = 0x66; /* Initialize A4  */
    P[1]    = 0xF2; /* Initialize A5  */
    P[2]    = 0xB0; /* Initialize A6  */
    P[3]    = 0x7D; /* Initialize A7  */
    P[4]    = 0x9C; /* Initialize A8  */
    P[5]    = 0xBB; /* Initialize A9  */
    P[6]    = 0x5E; /* Initialize A10 */
    P[7]    = 0xCA; /* Initialize A11 */
    P[8]    = 0xE1; /* Initialize A12 */
    P[9]    = 0x96; /* Initialize A13 */
    P[10]   = 0xB3; /* Initialize A14 */
    P[11]   = 0xE3; /* Initialize A15 */
    
    P[12]   = 0x1B; /* Initialize I0  */
    P[13]   = 0xCF; /* Initialize I1  */
    P[14]   = 0x0B; /* Initialize I2  */
    P[15]   = 0xC9; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x35; /* Initialize H0  */
    H[1]    = 0x7E; /* Initialize H1  */
    H[2]    = 0x69; /* Initialize H2  */
    H[3]    = 0x1A; /* Initialize H3  */
    H[4]    = 0xFC; /* Initialize H4  */
    H[5]    = 0x34; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 52 D3 30 5D 3B 15                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 58 9D B7 AC 24 66 52 E8 8E B7 22 4F B8 FA 01 FC       */
    /*  Identifier:    EF 10 4B 1E                                           */
    /*  Challenge:     7B 11 66 5C 76 2F                                     */
    /*                                                                        */
    /*  Response:      EE 83 35 69 FC B3                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x58; /* Initialize A0  */
    A[1]    = 0x9D; /* Initialize A1  */
    A[2]    = 0xB7; /* Initialize A2  */
    A[3]    = 0xAC; /* Initialize A3  */

    P[0]    = 0x24; /* Initialize A4  */
    P[1]    = 0x66; /* Initialize A5  */
    P[2]    = 0x52; /* Initialize A6  */
    P[3]    = 0xE8; /* Initialize A7  */
    P[4]    = 0x8E; /* Initialize A8  */
    P[5]    = 0xB7; /* Initialize A9  */
    P[6]    = 0x22; /* Initialize A10 */
    P[7]    = 0x4F; /* Initialize A11 */
    P[8]    = 0xB8; /* Initialize A12 */
    P[9]    = 0xFA; /* Initialize A13 */
    P[10]   = 0x01; /* Initialize A14 */
    P[11]   = 0xFC; /* Initialize A15 */
    
    P[12]   = 0xEF; /* Initialize I0  */
    P[13]   = 0x10; /* Initialize I1  */
    P[14]   = 0x4B; /* Initialize I2  */
    P[15]   = 0x1E; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x7B; /* Initialize H0  */
    H[1]    = 0x11; /* Initialize H1  */
    H[2]    = 0x66; /* Initialize H2  */
    H[3]    = 0x5C; /* Initialize H3  */
    H[4]    = 0x76; /* Initialize H4  */
    H[5]    = 0x2F; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: EE 83 35 69 FC B3                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 5E 2A DF 6B EC 9D A8 2D 6B D1 1C 13 40 29 09 AD       */
    /*  Identifier:    7E 54 4C 47                                           */
    /*  Challenge:     69 21 FB 3F C2 17                                     */
    /*                                                                       */
    /*  Response:      1F F2 52 75 36 AB                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x5E; /* Initialize A0  */
    A[1]    = 0x2A; /* Initialize A1  */
    A[2]    = 0xDF; /* Initialize A2  */
    A[3]    = 0x6B; /* Initialize A3  */

    P[0]    = 0xEC; /* Initialize A4  */
    P[1]    = 0x9D; /* Initialize A5  */
    P[2]    = 0xA8; /* Initialize A6  */
    P[3]    = 0x2D; /* Initialize A7  */
    P[4]    = 0x6B; /* Initialize A8  */
    P[5]    = 0xD1; /* Initialize A9  */
    P[6]    = 0x1C; /* Initialize A10 */
    P[7]    = 0x13; /* Initialize A11 */
    P[8]    = 0x40; /* Initialize A12 */
    P[9]    = 0x29; /* Initialize A13 */
    P[10]   = 0x09; /* Initialize A14 */
    P[11]   = 0xAD; /* Initialize A15 */
    
    P[12]   = 0x7E; /* Initialize I0  */
    P[13]   = 0x54; /* Initialize I1  */
    P[14]   = 0x4C; /* Initialize I2  */
    P[15]   = 0x47; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x69; /* Initialize H0  */
    H[1]    = 0x21; /* Initialize H1  */
    H[2]    = 0xFB; /* Initialize H2  */
    H[3]    = 0x3F; /* Initialize H3  */
    H[4]    = 0xC2; /* Initialize H4  */
    H[5]    = 0x17; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 1F F2 52 75 36 AB                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: 75 49 B0 FC AC A2 CF 0A A7 70 6D B9 AD 28 A5 0F       */
    /*  Identifier:    97 80 59 0A                                           */
    /*  Challenge:     96 A2 F5 8D 9E 26                                     */
    /*                                                                        */
    /*  Response:      26 81 7B 9E 66 AF                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0x75; /* Initialize A0  */
    A[1]    = 0x49; /* Initialize A1  */
    A[2]    = 0xB0; /* Initialize A2  */
    A[3]    = 0xFC; /* Initialize A3  */

    P[0]    = 0xAC; /* Initialize A4  */
    P[1]    = 0xA2; /* Initialize A5  */
    P[2]    = 0xCF; /* Initialize A6  */
    P[3]    = 0x0A; /* Initialize A7  */
    P[4]    = 0xA7; /* Initialize A8  */
    P[5]    = 0x70; /* Initialize A9  */
    P[6]    = 0x6D; /* Initialize A10 */
    P[7]    = 0xB9; /* Initialize A11 */
    P[8]    = 0xAD; /* Initialize A12 */
    P[9]    = 0x28; /* Initialize A13 */
    P[10]   = 0xA5; /* Initialize A14 */
    P[11]   = 0x0F; /* Initialize A15 */
    
    P[12]   = 0x97; /* Initialize I0  */
    P[13]   = 0x80; /* Initialize I1  */
    P[14]   = 0x59; /* Initialize I2  */
    P[15]   = 0x0A; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x96; /* Initialize H0  */
    H[1]    = 0xA2; /* Initialize H1  */
    H[2]    = 0x5F; /* Initialize H2  */
    H[3]    = 0x8D; /* Initialize H3  */
    H[4]    = 0x9E; /* Initialize H4  */
    H[5]    = 0x26; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 26 81 7B 9E 66 AF                         */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------------------------------------*/
    /*  Authenticator: BA 14 06 24 41 6A A1 6E 43 1B 19 A6 4B A8 15 7D       */
    /*  Identifier:    A4 6F C6 38                                           */
    /*  Challenge:     4C 42 A9 E8 FA E9                                     */
    /*                                                                        */
    /*  Response:      5B 8C 15 6A 1F 0F                                     */
    /*-----------------------------------------------------------------------*/
    A[0]    = 0xBA; /* Initialize A0  */
    A[1]    = 0x14; /* Initialize A1  */
    A[2]    = 0x06; /* Initialize A2  */
    A[3]    = 0x24; /* Initialize A3  */

    P[0]    = 0x41; /* Initialize A4  */
    P[1]    = 0x6A; /* Initialize A5  */
    P[2]    = 0xA1; /* Initialize A6  */
    P[3]    = 0x6E; /* Initialize A7  */
    P[4]    = 0x43; /* Initialize A8  */
    P[5]    = 0x1B; /* Initialize A9  */
    P[6]    = 0x19; /* Initialize A10 */
    P[7]    = 0xA6; /* Initialize A11 */
    P[8]    = 0x4B; /* Initialize A12 */
    P[9]    = 0xA8; /* Initialize A13 */
    P[10]   = 0x15; /* Initialize A14 */
    P[11]   = 0x7D; /* Initialize A15 */
    
    P[12]   = 0xA4; /* Initialize I0  */
    P[13]   = 0x6F; /* Initialize I1  */
    P[14]   = 0xC6; /* Initialize I2  */
    P[15]   = 0x38; /* Initialize I3  */

    for( Index=16; Index<29; Index++ )
    {              
        P[Index] = P[Index-16];         
    }               
    H[0]    = 0x4C; /* Initialize H0  */
    H[1]    = 0x42; /* Initialize H1  */
    H[2]    = 0xA9; /* Initialize H2  */
    H[3]    = 0xE8; /* Initialize H3  */
    H[4]    = 0xFA; /* Initialize H4  */
    H[5]    = 0xE9; /* Initialize H5  */

    CalcResponse();
    /*-----------------------------------------------------------------------*/
    /*  Response E should contain: 5B 8C 15 6A 1F 0F                         */
    /*-----------------------------------------------------------------------*/
}
    
