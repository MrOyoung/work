int bar()
{
int x=1;
int y=2;
return x+y;
}

int bar_()
{
int x=1;
return 2*x;
}
