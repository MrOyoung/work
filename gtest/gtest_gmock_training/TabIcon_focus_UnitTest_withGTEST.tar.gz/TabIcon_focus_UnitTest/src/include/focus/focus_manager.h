/*====================================================
 *FILE: focus_manager.h
 *Copyright: Saic Motor Group, All Rights Reserved
 * version: 1.0
 * author: yangxiaotao
 * created: 2017-06-01
 * DESCRIPTION: 
 *     focus manager definition
 * ABBREVIATIONS:
 *     N/A
 * TRACEABILITY INFO:
 *     N/A
 */

#ifndef FOCUS_MANAGER_H
#define FOCUS_MANAGER_H

#include "../hminode/hmi_node_manage.h"

class FocusManager {
public:
    /*===========================================================================*\
     * FUNCTION: Instance
     *===========================================================================
     * PARAMETERS:
     *     param: none
     * RETURN VALUE:
     *     a singleton object reference
     * --------------------------------------------------------------------------
     * ABSTRACT:
     *     create a singleton instance object
     */
    static FocusManager& Instance();

    ~FocusManager();
public:
    /*===========================================================================*\
     * FUNCTION: GetCurrentActive
     *===========================================================================
     * PARAMETERS:
     *     param: none
     * RETURN VALUE:
     *     current active node
     * --------------------------------------------------------------------------
     * ABSTRACT:
     *     get current active node object
     */
    LPClassForHMINode_Base GetCurrentActive();

    /*===========================================================================*\
     * FUNCTION: SetPopupmsgDisplay
     *===========================================================================
     * PARAMETERS:
     *     param: popup shown flag
     * RETURN VALUE:
     *     none
     * --------------------------------------------------------------------------
     * ABSTRACT:
     *     set popup shown flag
     */
    void SetPopupmsgDisplay(bool bdisplayed);

    /*===========================================================================*\
     * FUNCTION: GetPopupMsgDisplay
     *===========================================================================
     * PARAMETERS:
     *     param: none
     * RETURN VALUE:
     *     popup shown flag
     * --------------------------------------------------------------------------
     * ABSTRACT:
     *     get popup shown flag
     */
    bool GetPopupMsgDisplay();

    /*===========================================================================*\
     * FUNCTION: ProcessWithHardKey
     *===========================================================================
     * PARAMETERS:
     *     key: key value
     *     nData: message value associated with key
     * RETURN VALUE:
     *     none
     * --------------------------------------------------------------------------
     * ABSTRACT:
     *     process hard key message
     */
    void ProcessWithHardKey(unsigned int key, int nData);

    void ReturnToLastNode(void);
    void SetCurrentActive(LPClassForHMINode_Base);
private:
    FocusManager();
    LPClassForHMINode_Base m_pActiveNode;
    LPClassForHMINode_Base m_pLastActiveNode;
    bool m_bPopupmsgDisplay;
};

#endif //FOCUS_MANAGER_H

/*===========================================================================*\
 * File Revision History
 *===========================================================================
 * ----------- --------
 * 01-June-2017 yangxiaotao
 * + Created initial file
 *
\*===========================================================================*/
