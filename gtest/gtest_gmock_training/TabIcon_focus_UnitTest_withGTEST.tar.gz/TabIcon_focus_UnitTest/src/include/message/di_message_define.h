/*
* \file
* di message definition
*/

#ifndef DI_MESSAGE_DEFINE_H
#define DI_MESSAGE_DEFINE_H

#include "messages_definition.h"

typedef enum
{
    VEHICLE_MODE_RUN = 0,
    VEHICLE_MODE_POWEROFF
} VehicleMode;

typedef enum PopUpDisplayStatus
{
    POPUP_DISPLAYSTATUS_ON,
    POPUP_DISPLAYSTATUS_OFF,
}POPUPDISPLAYSTATUS;

typedef struct ReceiveData
{
public:
    ReceiveData(){}
    ReceiveData(const ReceiveData& input)
    {
        this->nMsgID = input.nMsgID;
        this->nData = input.nData;
        this->Data.sData.s_ndata1 = input.Data.sData.s_ndata1;
        this->Data.sData.s_ndata2 = input.Data.sData.s_ndata2;
        this->Data.sData.s_ndata3 = input.Data.sData.s_ndata3;
        this->Data.sData.s_ndata4 = input.Data.sData.s_ndata4;
        this->Data.sData.s_ndata5 = input.Data.sData.s_ndata5;
        this->Data.sData.s_ndata6 = input.Data.sData.s_ndata6;

        this->Data.iData.i_ndata1 = input.Data.iData.i_ndata1;
        this->Data.iData.i_ndata2 = input.Data.iData.i_ndata2;
        this->Data.iData.i_ndata3 = input.Data.iData.i_ndata3;

    }
    ~ReceiveData(){}
    ReceiveData& operator=(const ReceiveData& input)
    {
        this->nMsgID = input.nMsgID;
        this->nData = input.nData;
        this->Data.sData.s_ndata1 = input.Data.sData.s_ndata1;
        this->Data.sData.s_ndata2 = input.Data.sData.s_ndata2;
        this->Data.sData.s_ndata3 = input.Data.sData.s_ndata3;
        this->Data.sData.s_ndata4 = input.Data.sData.s_ndata4;
        this->Data.sData.s_ndata5 = input.Data.sData.s_ndata5;
        this->Data.sData.s_ndata6 = input.Data.sData.s_ndata6;

        this->Data.iData.i_ndata1 = input.Data.iData.i_ndata1;
        this->Data.iData.i_ndata2 = input.Data.iData.i_ndata2;
        this->Data.iData.i_ndata3 = input.Data.iData.i_ndata3;
        return *this;
    }
public:
    unsigned int nMsgID;
    unsigned int nData;
    union UnionData {
        struct ShortData {
            unsigned short s_ndata1;
            unsigned short s_ndata2;
            unsigned short s_ndata3;
            unsigned short s_ndata4;
            unsigned short s_ndata5;
            unsigned short s_ndata6;
        } sData;
        struct IntData {
            unsigned int i_ndata1;
            unsigned int i_ndata2;
            unsigned int i_ndata3;
        } iData;
    } Data;
}sRECEIVEDATA;

enum DI_Message_TYPE
{
    DI_MESSAGE_ID_UNKNOW = -1,
    DI_MESSAGE_ID_SPEED,
    DI_MESSAGE_ID_WATERTEMP,
    DI_MESSAGE_ID_HARDKEY,
    DI_MESSAGE_ID_POPUP,
    DI_MESSAGE_ID_MAX,
};

enum HARDKEY_OPERATION
{
    E_HARDKEY_UNKNOW,
    E_HARDKEY_UP,
    E_HARDKEY_DOWN,
    E_HARDKEY_LEFT,
    E_HARDKEY_RIGHT,
    E_HARDKEY_OK,
    E_HARDKEY_OK_LONG,
    E_HARDKEY_MAX,
};

#endif //DI_MESSAGE_DEFINE_H
