#ifndef HMI_NODE_DEFINE_H
#define HMI_NODE_DEFINE_H

///////////**********Step1: Define NodeName
enum HMI_NODE_NAME
{
    E_HMINODE_NODE_INVAILD = -1,
    E_HMINODE_NODE_TOP,    ////0
    ///////////Node Name start ////

    E_HMINODE_LEVEL_1_DrivingComputer,
    E_HMINODE_LEVEL_1_DrivingComputer_2_vehiclestate,
    E_HMINODE_LEVEL_1_DrivingComputer_2_steerangle,
    E_HMINODE_LEVEL_1_DrivingComputer_2_batterystate,
    E_HMINODE_LEVEL_1_DrivingComputer_2_accelerator,
    E_HMINODE_LEVEL_1_DrivingComputer_2_afterstart,
    E_HMINODE_LEVEL_1_DrivingComputer_2_afterreset,
    E_HMINODE_LEVEL_1_DrivingComputer_2_consumptiontend,
    E_HMINODE_LEVEL_1_DrivingComputer_2_maintenanceinfo,

    E_HMINODE_LEVEL_1_Alarm,

    E_HMINODE_LEVEL_1_SETTING,
    E_HMINODE_LEVEL_1_SETTING_2_Brightness,
    E_HMINODE_LEVEL_1_SETTING_2_Brightness_3,
    E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit,
    E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit_3_SpeedLimitSwitch,
    E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit_3_SpeedLimit,
    E_HMINODE_LEVEL_1_SETTING_2_Theme,
    E_HMINODE_LEVEL_1_SETTING_2_Theme_3,
    E_HMINODE_LEVEL_1_SETTING_2_Time,
    E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time12or24,
    E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time_h,
    E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time_m,
    E_HMINODE_LEVEL_1_SETTING_2_Time_3_TimeAMorPM,
    E_HMINODE_LEVEL_1_SETTING_2_Language,
    E_HMINODE_LEVEL_1_SETTING_2_Language_3,
    E_HMINODE_LEVEL_1_SETTING_2_Unit,
    E_HMINODE_LEVEL_1_SETTING_2_Unit_3_ODOUNIT,
    E_HMINODE_LEVEL_1_SETTING_2_Unit_3_FUELUNIT,
    E_HMINODE_LEVEL_1_SETTING_2_Unit_3_TEMPUNIT,
    E_HMINODE_LEVEL_1_Contacts,
    //E_HMINODE_LEVEL_1_ADAS,
    ///////////Node Name end ////
    E_HMINODE_NODE_MAX,
    E_HMINODE_NODE_END

};

#endif // HMI_NODE_DEFINE_H
