/*
* \file
* node class factory to generate/manager all node
*/

#ifndef NODE_CLASS_FACTORY_H
#define NODE_CLASS_FACTORY_H

#include "class_for_hmi_node.h"
#include "hmi_node_define.h"
class CNodeClassFactory
{
public:
    static CNodeClassFactory& FactoryInstance();
    LPClassForHMINode_Base CreateAndInitNodeClass(HMI_NODE_NAME);
    ~CNodeClassFactory();
private:
    CNodeClassFactory();
	
};

#endif
