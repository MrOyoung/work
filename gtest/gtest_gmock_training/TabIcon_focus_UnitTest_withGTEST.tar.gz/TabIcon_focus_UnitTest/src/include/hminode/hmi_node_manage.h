/*===========================================================================*\
 * FILE: hmi_node_manage.h
 *===========================================================================
 * Copyright SAIC Motor Technologies, Inc., All Rights Reserved.
 * SAIC Confidential
 *---------------------------------------------------------------------------
 * HMI node manage to generate/manager all node :
 * %version : 1.0.0.0
 * %author  : Zhao Zhengsong
 * %created : 2017/06/01
 *---------------------------------------------------------------------------
 *
 * DESCRIPTION:
 *   Manage TabIcon nodes.
 *
 * ABBREVIATIONS:
 *   none
 *
 * TRACEABILITY INFO:
 *   Design Document(s):
 *   none
 *   Requirements Document(s):
 *   none
\*===========================================================================*/

#ifndef HMI_NODE_MANAGE_H
#define HMI_NODE_MANAGE_H

#include "./class_for_hmi_node.h"
#include "../../tools/tinyxml2/tinyxml2.h"

using namespace tinyxml2;

class CHMINodeManage
{
public:
    /*===========================================================================*\
     * FUNCTION: Instance
     *===========================================================================
     * PARAMETERS:
     * none
     *
     * RETURN VALUE:
     * reference of CHMINodeManage
     *
     * --------------------------------------------------------------------------
     * ABSTRACT:
     * --------------------------------------------------------------------------
     * For Create once, so use this function to get class Instance
    \*===========================================================================*/
    static CHMINodeManage& Instance();

    /*===========================================================================*\
     * FUNCTION: ~CHMINodeManage
     *===========================================================================
     * PARAMETERS:
     * none
     *
     * RETURN VALUE:
     * none
     *
     * --------------------------------------------------------------------------
     * ABSTRACT:
     * --------------------------------------------------------------------------
     * Destractor
    \*===========================================================================*/
    ~CHMINodeManage();
    /*===========================================================================*\
     * FUNCTION: FindFirstDefaultActiveNode
     *===========================================================================
     * PARAMETERS:
     * none
     *
     * RETURN VALUE:
     * LPClassForHMINode_Base : Default Active Node
     *
     * --------------------------------------------------------------------------
     * ABSTRACT:
     * --------------------------------------------------------------------------
     * Get Default Active Node
    \*===========================================================================*/
    LPClassForHMINode_Base FindFirstDefaultActiveNode(void);
	
private:
    CHMINodeManage();
    void CreateAllNodeClass(void);
    void DeleteAllNodeClass(void);
    void InitAllNodeClass(void);
    void InitXMLData(void);

    bool aToBool(const char*);
public:
    LPClassForHMINode_Base AllNodeClass_List[E_HMINODE_NODE_MAX];
    const char * m_xml;
};




#endif
