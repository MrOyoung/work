/*
* \file
* hmi node class definition
*/

#ifndef CLASS_FOR_HMI_NODE_H
#define CLASS_FOR_HMI_NODE_H
#include <list>

#include "../message/di_message_define.h"
#include "hmi_node_define.h"
//using namespace std;

class ClassForHMINode_Base;
typedef ClassForHMINode_Base* LPClassForHMINode_Base;

class ClassForHMINode_Base
{
public:
    ClassForHMINode_Base(bool bcanfouced,HMI_NODE_NAME name = E_HMINODE_NODE_INVAILD);
    virtual ~ClassForHMINode_Base();
    virtual bool OnKeyEvent(HARDKEY_OPERATION ekeyevent, LPClassForHMINode_Base & FoucedNodeAfterEvent);
    bool IsCanFouced(){return _bCanFouced;}
    HMI_NODE_NAME GetNodeName(){return _nodeName;}
    LPClassForHMINode_Base GetDefaultActiveSon(){return _DefaultActiveSon;}
    int FindIndexInSonList(LPClassForHMINode_Base pnode);
    LPClassForHMINode_Base FindNodeByIndex(unsigned int index);
public:
    std::list<LPClassForHMINode_Base> m_pSonNodeList;
    LPClassForHMINode_Base m_pParentNode;
	
public:	
    LPClassForHMINode_Base _DefaultActiveSon;
    bool _bCanFouced;
    HMI_NODE_NAME _nodeName;
    bool  bHasParam;
    int   iParam;
};

class CNodeForLevel_1 : public ClassForHMINode_Base
{
public:
    CNodeForLevel_1(bool bcanfouced,HMI_NODE_NAME name = E_HMINODE_NODE_INVAILD);
    ~CNodeForLevel_1(){}
    bool OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent);
};

class CNodeForLevel_2 : public ClassForHMINode_Base
{
public:
    CNodeForLevel_2(bool bcanfouced,HMI_NODE_NAME name = E_HMINODE_NODE_INVAILD);
    ~CNodeForLevel_2(){}
    bool OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent);
};
class CNodeForLevel_3 : public ClassForHMINode_Base
{
public:
    CNodeForLevel_3(bool bcanfouced,HMI_NODE_NAME name = E_HMINODE_NODE_INVAILD);
    ~CNodeForLevel_3(){}
    bool OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent);
private:
};

#endif //CLASS_FOR_HMI_NODE_H
