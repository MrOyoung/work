#include "../include/focus/focus_manager.h"
#include "../include/message/di_message_define.h"

FocusManager& FocusManager::Instance()
{
    static FocusManager sFocusManager;
    return sFocusManager;
}

FocusManager::~FocusManager()
{
    if(m_pActiveNode != NULL)
    {
        m_pActiveNode = NULL;
    }
}

LPClassForHMINode_Base FocusManager::GetCurrentActive()
{
    return m_pActiveNode;
}

void FocusManager::SetPopupmsgDisplay(bool bDisplayed)
{
    m_bPopupmsgDisplay = bDisplayed;
}

bool FocusManager::GetPopupMsgDisplay()
{
    return m_bPopupmsgDisplay;
}

void FocusManager::ProcessWithHardKey(unsigned int key, int nData)
{
    HARDKEY_OPERATION myKey = E_HARDKEY_UNKNOW;
    switch(key)
    {
        case SERVICE_DI_BUTTON_KEY_RIGHT:
            myKey = E_HARDKEY_RIGHT;
            break;
        case SERVICE_DI_BUTTON_KEY_LEFT:
            myKey = E_HARDKEY_LEFT;
            break;
        case SERVICE_DI_BUTTON_KEY_UP:
            myKey = E_HARDKEY_UP;
            break;
        case SERVICE_DI_BUTTON_KEY_DOWN:
            myKey = E_HARDKEY_DOWN;
            break;
        case SERVICE_DI_BUTTON_KEY_ENTER:
            if(1 == nData){
                myKey = E_HARDKEY_OK;
            }else if(2 == nData){
                myKey = E_HARDKEY_OK_LONG;
            }
            break;
        default:
            myKey = E_HARDKEY_UNKNOW;
            break;
    }
    if(E_HARDKEY_UNKNOW != myKey)
    {
        LPClassForHMINode_Base pCurrentnode = m_pActiveNode;
        bool bRet = false;
        LPClassForHMINode_Base pFoucedNodeAfterEvent = NULL;
        while(false == bRet)
        {
            bRet = pCurrentnode->OnKeyEvent(myKey, pFoucedNodeAfterEvent);
            if(false == bRet)
            {
                pCurrentnode = m_pActiveNode->m_pParentNode;
                if(NULL == pCurrentnode)
                {
                    break;
                }
            }
            else
            {
                if(NULL != pFoucedNodeAfterEvent)
                {
                    bool bHasFouceNode = false;
                    while(false == bHasFouceNode)
                    {
                        bHasFouceNode = pFoucedNodeAfterEvent->IsCanFouced();
                        if(false == bHasFouceNode)
                        {
                            pFoucedNodeAfterEvent = pFoucedNodeAfterEvent->_DefaultActiveSon;
                            if(NULL == pFoucedNodeAfterEvent)
                            {
                                break;
                            }
                        }else{
                            m_pActiveNode = pFoucedNodeAfterEvent;
                        }
                    }
                    
                    pFoucedNodeAfterEvent = pFoucedNodeAfterEvent->GetDefaultActiveSon();
                }
                else
                {
                    break;
                }
            }
        }
        m_pLastActiveNode = m_pActiveNode;
    }
}

void FocusManager::ReturnToLastNode()
{
    m_pActiveNode = m_pLastActiveNode;
}

void FocusManager::SetCurrentActive(LPClassForHMINode_Base pc)
{
    m_pActiveNode = pc;
}

FocusManager::FocusManager()
    : m_pActiveNode(CHMINodeManage::Instance().FindFirstDefaultActiveNode())
    , m_bPopupmsgDisplay(false)
    , m_pLastActiveNode(NULL)
{}
