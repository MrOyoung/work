#!/bin/bash

GCOVR="./gcovr"

echo "Starting coverage report generating..."

$GCOVR --html --html-detail \
	-e ".+/bits/.+"	\
	-o coverage.html

echo "Generate done!"
