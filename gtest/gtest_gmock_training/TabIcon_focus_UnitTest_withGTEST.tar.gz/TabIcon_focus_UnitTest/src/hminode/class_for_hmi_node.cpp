#include "../include/hminode/class_for_hmi_node.h"

#define NULL (0)

ClassForHMINode_Base::ClassForHMINode_Base(bool bcanfouced, HMI_NODE_NAME name): m_pParentNode(NULL),
                                                                                  _bCanFouced(bcanfouced),
                                                                                  _DefaultActiveSon(NULL),
                                                                                  _nodeName(name),
                                                                                  bHasParam(false),
                                                                                  iParam(0)
{
}

ClassForHMINode_Base::~ClassForHMINode_Base(){

}

int ClassForHMINode_Base::FindIndexInSonList(LPClassForHMINode_Base pnode)
{ 
    int nindex = -1;
    std::list<LPClassForHMINode_Base>::iterator it = m_pSonNodeList.begin();
    for(int i = 0;it != m_pSonNodeList.end(); it++, i++)
    {
        if (pnode == *it)
        {
            nindex = i;
            break;
        }
    }
    return nindex;
}
LPClassForHMINode_Base ClassForHMINode_Base::FindNodeByIndex(unsigned int index)
{
    LPClassForHMINode_Base pret = NULL;
    std::list<LPClassForHMINode_Base>::iterator it = m_pSonNodeList.begin();
    for(int i = 0;it != m_pSonNodeList.end(); it++, i++)
    {
        if (i == index)
        {
            pret = *it;
            break;
        }
    }
    return pret;
}

bool ClassForHMINode_Base::OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent)
{
    return true;
}

CNodeForLevel_1::CNodeForLevel_1(bool bcanfouced,HMI_NODE_NAME name):ClassForHMINode_Base(bcanfouced,name)
{
	
}
bool CNodeForLevel_1::OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent)
{
    bool bRet = false;
    iParam = ekeyevent;
    switch(ekeyevent)
    {
    case E_HARDKEY_LEFT:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(--nindex < 0)
                {
                    nindex = nSize - 1;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_RIGHT:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(++nindex >= nSize)
                {
                    nindex = 0;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    default:
            break;
    }

    return bRet;
}

CNodeForLevel_2::CNodeForLevel_2(bool bcanfouced,HMI_NODE_NAME name):ClassForHMINode_Base(bcanfouced,name)
{

}

bool CNodeForLevel_2::OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent)
{
    bool bRet = false;
    iParam = ekeyevent;
    switch(ekeyevent)
    {
    case E_HARDKEY_UP:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(--nindex < 0)
                {
                    nindex = nSize - 1;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_DOWN:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(++nindex >= nSize)
                {
                    nindex = 0;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_OK:
    {
        if(NULL != _DefaultActiveSon)
        {
            FoucedNodeAfterEvent = _DefaultActiveSon;
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_OK_LONG:
    {
        FoucedNodeAfterEvent = this;
        bRet = true;
        break;
    }
    default:
        break;
    }
    return bRet;
}


CNodeForLevel_3::CNodeForLevel_3(bool bcanfouced,HMI_NODE_NAME name):ClassForHMINode_Base(bcanfouced,name)
{
        bHasParam = true;
}
bool CNodeForLevel_3::OnKeyEvent(HARDKEY_OPERATION ekeyevent,LPClassForHMINode_Base& FoucedNodeAfterEvent)
{
    bool bRet = false;
    iParam = ekeyevent;
    switch(ekeyevent)
    {
    case E_HARDKEY_LEFT:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(--nindex < 0)
                {
                    nindex = 0;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_RIGHT:
    {
        if(NULL != m_pParentNode)
        {
            int nindex = m_pParentNode->FindIndexInSonList(this);
            int nSize = m_pParentNode->m_pSonNodeList.size();
            if((nindex >= 0) && (nindex < nSize))
            {
                if(++nindex >= nSize)
                {
                    nindex = nSize - 1;
                }
                FoucedNodeAfterEvent = m_pParentNode->FindNodeByIndex(nindex);
            }
        }
        bRet = true;
        break;
    }
    case E_HARDKEY_UP:
    case E_HARDKEY_DOWN:
    {
        FoucedNodeAfterEvent = this;
        bRet = true;
        break;
    }
    case E_HARDKEY_OK:
    {
        if(NULL != m_pParentNode)
        {
            FoucedNodeAfterEvent = m_pParentNode;
        }
        bRet = true;
        break;
    }
    default:
            break;
    }
    return bRet;
}
