#include "../include/hminode/node_class_factory.h"

#define NULL (0)

CNodeClassFactory& CNodeClassFactory::FactoryInstance(){
    static CNodeClassFactory factoryInstance;
    return factoryInstance;
}

LPClassForHMINode_Base CNodeClassFactory::CreateAndInitNodeClass(HMI_NODE_NAME name)
{
    LPClassForHMINode_Base pNode = NULL;
    if(name > E_HMINODE_NODE_MAX || name < E_HMINODE_NODE_TOP)
    {
        pNode = NULL;
        return pNode;
    }

    switch(name)
    {
    case E_HMINODE_LEVEL_1_SETTING:

    case E_HMINODE_LEVEL_1_Alarm:
    case E_HMINODE_LEVEL_1_DrivingComputer:

    //case E_HMINODE_LEVEL_1_ADAS:
    case E_HMINODE_LEVEL_1_Contacts:
            pNode = new CNodeForLevel_1(false, name);
            break;
    case E_HMINODE_LEVEL_1_SETTING_2_Brightness:
    case E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit:
    case E_HMINODE_LEVEL_1_SETTING_2_Theme:
    case E_HMINODE_LEVEL_1_SETTING_2_Time:
    case E_HMINODE_LEVEL_1_SETTING_2_Language:
    case E_HMINODE_LEVEL_1_SETTING_2_Unit:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_vehiclestate:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_steerangle:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_batterystate:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_accelerator:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_afterstart:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_afterreset:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_consumptiontend:
    case E_HMINODE_LEVEL_1_DrivingComputer_2_maintenanceinfo:
            pNode = new CNodeForLevel_2(false, name);
            break;
    case E_HMINODE_LEVEL_1_SETTING_2_Brightness_3:
    case E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit_3_SpeedLimitSwitch:
    case E_HMINODE_LEVEL_1_SETTING_2_SpeedLimit_3_SpeedLimit:
    case E_HMINODE_LEVEL_1_SETTING_2_Theme_3:
    case E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time12or24:
    case E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time_h:
    case E_HMINODE_LEVEL_1_SETTING_2_Time_3_Time_m:
    case E_HMINODE_LEVEL_1_SETTING_2_Time_3_TimeAMorPM:
    case E_HMINODE_LEVEL_1_SETTING_2_Language_3:
    case E_HMINODE_LEVEL_1_SETTING_2_Unit_3_ODOUNIT:
    case E_HMINODE_LEVEL_1_SETTING_2_Unit_3_FUELUNIT:
    case E_HMINODE_LEVEL_1_SETTING_2_Unit_3_TEMPUNIT:
            pNode = new CNodeForLevel_3(false, name);
            break;
    default:
            pNode = new ClassForHMINode_Base(false, name);
            break;
    }
}

CNodeClassFactory::CNodeClassFactory()
{
}

CNodeClassFactory::~CNodeClassFactory()
{
}
