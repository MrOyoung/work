#include "../include/hminode/hmi_node_manage.h"
#include "../include/hminode/node_class_factory.h"

CHMINodeManage& CHMINodeManage::Instance(){
    static CHMINodeManage Instance;
    return Instance;
}

CHMINodeManage::CHMINodeManage()
{
    CreateAllNodeClass();
    InitAllNodeClass();
}

CHMINodeManage::~CHMINodeManage()
{
    DeleteAllNodeClass();
}

void CHMINodeManage::CreateAllNodeClass()
{
    for(int i = 0; i< E_HMINODE_NODE_MAX; i++)
    {
       AllNodeClass_List[i] = CNodeClassFactory::FactoryInstance().CreateAndInitNodeClass((HMI_NODE_NAME)i);
    }
}

void CHMINodeManage::InitAllNodeClass()
{
   InitXMLData();
   XMLDocument * doc = new XMLDocument();
   XMLError err = doc->Parse(m_xml);

   if(XML_SUCCESS != err)
   {
       return ;
   }
   XMLElement* root = doc->RootElement();
   XMLElement* node1 = root->FirstChildElement("Node1");
   int nodeIndex = 0;
   AllNodeClass_List[E_HMINODE_NODE_TOP]->_bCanFouced = false;
   AllNodeClass_List[E_HMINODE_NODE_TOP]->_nodeName = E_HMINODE_NODE_TOP;
   while (NULL != node1)
   {
        nodeIndex++;
        const XMLAttribute * nameAttr1 = node1->FirstAttribute();
        const XMLAttribute * canFocus1 = nameAttr1->Next();
        bool  node1Focus = aToBool(canFocus1->Value());
        int  node1Value = nodeIndex;

        AllNodeClass_List[node1Value]->_bCanFouced = node1Focus;
        AllNodeClass_List[node1Value]->m_pParentNode = AllNodeClass_List[E_HMINODE_NODE_TOP];
        AllNodeClass_List[E_HMINODE_NODE_TOP]->m_pSonNodeList.push_back(AllNodeClass_List[node1Value]);
        XMLElement* node2 = node1->FirstChildElement("Node2");
        while (NULL != node2)
        {
            nodeIndex++;
            const XMLAttribute * nameAttr2 = node2->FirstAttribute();
            const XMLAttribute * canFocus2 = nameAttr2->Next();
            bool  node2Focus = aToBool(canFocus2->Value());
            int  node2Value = nodeIndex;
            AllNodeClass_List[node2Value]->_bCanFouced = node2Focus;
            AllNodeClass_List[node2Value]->m_pParentNode = AllNodeClass_List[node1Value];
            AllNodeClass_List[node1Value]->m_pSonNodeList.push_back(AllNodeClass_List[node2Value]);
            XMLElement* node3 = node2->FirstChildElement("Node3");
            while (NULL != node3)
            {
                nodeIndex++;
                const XMLAttribute * nameAttr3 = node3->FirstAttribute();
                const XMLAttribute * canFocus3 = nameAttr3->Next();
                bool  node3Focus = aToBool(canFocus3->Value());
                int  node3Value = nodeIndex;
                AllNodeClass_List[node3Value]->_bCanFouced = node3Focus;
                AllNodeClass_List[node3Value]->m_pParentNode = AllNodeClass_List[node2Value];
                AllNodeClass_List[node2Value]->m_pSonNodeList.push_back(AllNodeClass_List[node3Value]);

                if(NULL == AllNodeClass_List[node2Value]->_DefaultActiveSon)
                {
                    AllNodeClass_List[node2Value]->_DefaultActiveSon = AllNodeClass_List[node3Value];
                }

                node3 =  node3->NextSiblingElement();
            }

            if(NULL == AllNodeClass_List[node1Value]->_DefaultActiveSon)
            {
                AllNodeClass_List[node1Value]->_DefaultActiveSon = AllNodeClass_List[node2Value];
            }

            node2 =  node2->NextSiblingElement();
        }

        if(NULL == AllNodeClass_List[E_HMINODE_NODE_TOP]->_DefaultActiveSon)
        {
            AllNodeClass_List[E_HMINODE_NODE_TOP]->_DefaultActiveSon = AllNodeClass_List[node1Value];
        }

        node1 =  node1->NextSiblingElement();
   }
   delete doc;
}

bool CHMINodeManage::aToBool(const char * buff)
{
    bool ret = false;
    if(strcmp(buff, "true") == 0)
    {
        ret = true;
    }
    else if(strcmp(buff, "false") == 0){
        ret = false;
    }

    return ret;
}

void CHMINodeManage::InitXMLData()
{
#if 0   /* two layers */
    m_xml = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\
            <root>\
                <Node1 name='DrivingComputer' CanFocus='false'>\
                    <Node2 name='vehiclestate' CanFocus='true'></Node2>\
                    <Node2 name='steerangle' CanFocus='true'></Node2>\
                    <Node2 name='batterystate' CanFocus='true'></Node2>\
                    <Node2 name='accelerator' CanFocus='true'></Node2>\
                    <Node2 name='afterstart' CanFocus='true'></Node2>\
                    <Node2 name='afterreset' CanFocus='true'></Node2>\
                    <Node2 name='consumptiontend' CanFocus='true'></Node2>\
                    <Node2 name='maintenanceinfo' CanFocus='true'></Node2>\
                </Node1>\
                <Node1 name='Alarm' CanFocus='true'>\
                </Node1>\
                <Node1 name='Setting' CanFocus='false'>\
                    <Node2 name='Brightness' CanFocus='true'></Node2>\
                    <Node2 name='SpeedLimit' CanFocus='true'></Node2>\
                    <Node2 name='Theme' CanFocus='true'></Node2>\
                    <Node2 name='Time' CanFocus='true'></Node2>\
                    <Node2 name='Language' CanFocus='true'></Node2>\
                    <Node2 name='Unit' CanFocus='true'></Node2></Node1>\
                <Node1 name='Contacts' CanFocus='true'></Node1>\
                <Node1 name='ADAS' CanFocus='true'>\
                </Node1>\
            </root>";
 #else   /* three layers */
     m_xml = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\
             <root>\
                 <Node1 name='DrivingComputer' CanFocus='false'>\
                     <Node2 name='vehiclestate' CanFocus='true'></Node2>\
                     <Node2 name='steerangle' CanFocus='true'></Node2>\
                     <Node2 name='batterystate' CanFocus='true'></Node2>\
                     <Node2 name='accelerator' CanFocus='true'></Node2>\
                     <Node2 name='afterstart' CanFocus='true'></Node2>\
                     <Node2 name='afterreset' CanFocus='true'></Node2>\
                     <Node2 name='consumptiontend' CanFocus='true'></Node2>\
                     <Node2 name='maintenanceinfo' CanFocus='true'></Node2>\
                 </Node1>\
                 <Node1 name='Alarm' CanFocus='true'>\
                 </Node1>\
                 <Node1 name='Setting' CanFocus='false'>\
                     <Node2 name='Brightness' CanFocus='true'>\
                         <Node3 name='BrightnessSet' CanFocus='true'></Node3>\
                     </Node2>\
                     <Node2 name='SpeedLimit' CanFocus='true'>\
                         <Node3 name='SpeedLimitSwitch' CanFocus='true'></Node3>\
                         <Node3 name='SpeedLimitSet' CanFocus='true'></Node3>\
                     </Node2>\
                     <Node2 name='Theme' CanFocus='true'>\
                         <Node3 name='ThemeSet' CanFocus='true'></Node3>\
                     </Node2>\
                     <Node2 name='Time' CanFocus='true'>\
                         <Node3 name='Time12or24' CanFocus='true'></Node3>\
                         <Node3 name='timeh' CanFocus='true'></Node3>\
                         <Node3 name='timem' CanFocus='true'></Node3>\
                         <Node3 name='timeAMorPM' CanFocus='true'></Node3>\
                     </Node2>\
                     <Node2 name='Language' CanFocus='true'>\
                         <Node3 name='LanguageSet' CanFocus='true'></Node3>\
                     </Node2>\
                     <Node2 name='Unit' CanFocus='true'>\
                         <Node3 name='ODOUnit' CanFocus='true'></Node3>\
                         <Node3 name='FuelUnit' CanFocus='true'></Node3>\
                         <Node3 name='TempUnit' CanFocus='true'></Node3>\
                     </Node2>\
                 </Node1>\
                 <Node1 name='Contacts' CanFocus='true'></Node1>\
             </root>";
#endif
}

void CHMINodeManage::DeleteAllNodeClass()
{
    for(int i = 0; i < E_HMINODE_NODE_MAX; i++)
    {
        if (NULL != AllNodeClass_List[i])
        {
            delete AllNodeClass_List[i];
            AllNodeClass_List[i] = NULL;
         }
    }
}

LPClassForHMINode_Base CHMINodeManage::FindFirstDefaultActiveNode(void)
{
    LPClassForHMINode_Base pCurrent = AllNodeClass_List[E_HMINODE_LEVEL_1_DrivingComputer_2_vehiclestate];
//    while(false == pCurrent->_bCanFouced)
//    {
//        if(pCurrent->_DefaultActiveSon != NULL)
//        {
//            pCurrent = pCurrent->_DefaultActiveSon;
//         }
//         else
//         {
//            break;
//         }
//    }
    return pCurrent;
}
