#ifndef _HELLO_GTEST_H_
#define _HELLO_GTEST_H_
#include "GreatestCommonDivisor.h"
#endif
