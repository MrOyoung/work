#ifndef _GCD_H_
#define _GCD_H_
int Gcd(int a, int b);

bool IsPrime(int n);

void FailedFunc();
#endif