#include <iostream>
using namespace std;
#include "func.h"

int func(int a, int b)
{
    return a+b;
}